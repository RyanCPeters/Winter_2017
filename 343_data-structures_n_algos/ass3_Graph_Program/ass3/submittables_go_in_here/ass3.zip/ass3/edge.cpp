//
// Created by R.Peters on 2/16/2018.
//

/** I've moved all of the code used for the edge class to its header file so
 * I could implement a templated class structure that ended up making it
 * easier to manage vertex pointer in my various maps, vectors, and qwayways.
 *
 * I've kept the edge.cpp file here with the include statement purely for
 * compatability with the graders test scripts, sorry if this was confusing
 * looking.
 *
 */


#include "edge.h"

